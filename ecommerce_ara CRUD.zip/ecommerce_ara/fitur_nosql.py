# fitur_nosql.py
from mongo_conn import connect_mongo

def tampilkan_feedback():
    db = connect_mongo()
    for doc in db.review.find():
        print(f"User {doc['id_user']} beri rating {doc['rating']} ke produk {doc['id_produk']}")


def tambah_feedback(id_user, id_produk, rating):
    db = connect_mongo()
    review = {
        "id_user": id_user,
        "id_produk": id_produk,
        "rating": rating
    }
    db.review.insert_one(review)
    print("Feedback berhasil ditambahkan.")

def update_feedback(id_user, id_produk, rating_baru):
    db = connect_mongo()
    result = db.review.update_one(
        {"id_user": id_user, "id_produk": id_produk},
        {"$set": {"rating": rating_baru}}
    )
    if result.modified_count:
        print("Feedback berhasil diperbarui.")
    else:
        print("Feedback tidak ditemukan.")

def hapus_feedback(id_user, id_produk):
    db = connect_mongo()
    result = db.review.delete_one(
        {"id_user": id_user, "id_produk": id_produk}
    )
    if result.deleted_count:
        print("Feedback berhasil dihapus.")
    else:
        print("Feedback tidak ditemukan.")