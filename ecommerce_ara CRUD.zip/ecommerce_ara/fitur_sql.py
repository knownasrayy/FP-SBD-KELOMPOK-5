from mysql_conn import connect_mysql

def tampilkan_produk():
    db = connect_mysql()
    cursor = db.cursor()
    cursor.execute("SELECT id_produk, nama_produk, harga, stok, deskripsi FROM produk")
    for row in cursor.fetchall():
        print(f"[ID {row[0]}] {row[1]} - Rp{int(row[2])} - Stok: {row[3]} - {row[4]}")
    cursor.close()
    db.close()

def tambah_produk():
    db = connect_mysql()
    cursor = db.cursor()

    # Buat nampilin daftar kategori agar user tahu idnya
    cursor.execute("SELECT id_kategori, nama_kategori FROM kategori")
    kategori_list = cursor.fetchall()

    print("\n Daftar Kategori:")
    for k in kategori_list:
        print(f"{k[0]}. {k[1]}")

    # Input ID kategori dengan validasi
    while True:
        try:
            id_kategori = int(input("Masukkan ID kategori produk: "))
            cursor.execute("SELECT COUNT(*) FROM kategori WHERE id_kategori = %s", (id_kategori,))
            if cursor.fetchone()[0] > 0:
                break
            else:
                print("ID kategori tidak ditemukan. Coba lagi.")
        except ValueError:
            print("Masukkan angka yang valid untuk ID kategori.")

    # Input produk lainnya
    nama = input("Nama produk: ")
    harga = int(input("Harga: "))

    stok_input = input("Stok (kosongkan untuk 0): ")
    deskripsi_input = input("Deskripsi (kosongkan untuk default): ")

    stok = int(stok_input) if stok_input.strip() else 0
    deskripsi = deskripsi_input.strip() if deskripsi_input.strip() else "Tidak ada deskripsi"

    # buat produk ke database
    cursor.execute(
        "INSERT INTO produk (id_kategori, nama_produk, harga, stok, deskripsi) VALUES (%s, %s, %s, %s, %s)",
        (id_kategori, nama, harga, stok, deskripsi)
    )
    db.commit()
    print("Produk berhasil ditambahkan.")

    cursor.close()
    db.close()

def update_produk():
    db = connect_mysql()
    cursor = db.cursor()

    id_produk = input("ID produk yang ingin diupdate: ")
    cursor.execute("SELECT * FROM produk WHERE id_produk = %s", (id_produk,))
    if not cursor.fetchone():
        print("Produk tidak ditemukan.")
        return

    nama = input("Nama baru (kosongkan jika tidak diubah): ")
    harga = input("Harga baru (kosongkan jika tidak diubah): ")
    stok = input("Stok baru (kosongkan jika tidak diubah): ")
    deskripsi = input("Deskripsi baru (kosongkan jika tidak diubah): ")

    fields = []
    values = []

    if nama:
        fields.append("nama_produk = %s")
        values.append(nama)
    if harga:
        fields.append("harga = %s")
        values.append(int(harga))
    if stok:
        fields.append("stok = %s")
        values.append(int(stok))
    if deskripsi:
        fields.append("deskripsi = %s")
        values.append(deskripsi)

    if fields:
        query = f"UPDATE produk SET {', '.join(fields)} WHERE id_produk = %s"
        values.append(id_produk)
        cursor.execute(query, tuple(values))
        db.commit()
        print("Produk berhasil diupdate.")
    else:
        print("❕ Tidak ada data yang diubah.")

    cursor.close()
    db.close()

def hapus_produk():
    db = connect_mysql()
    cursor = db.cursor()

    id_produk = input("ID produk yang ingin dihapus: ")
    cursor.execute("SELECT * FROM produk WHERE id_produk = %s", (id_produk,))
    if not cursor.fetchone():
        print("Produk tidak ditemukan.")
        return

    konfirmasi = input(f"Yakin ingin menghapus produk ID {id_produk}? (y/n): ")
    if konfirmasi.lower() == 'y':
        cursor.execute("DELETE FROM produk WHERE id_produk = %s", (id_produk,))
        db.commit()
        print("Produk berhasil dihapus.")
    else:
        print("Penghapusan dibatalkan.")

    cursor.close()
    db.close()

def tampilkan_laporan_transaksi():
    db = connect_mysql()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM v_laporan_transaksi")
    for row in cursor.fetchall():
        print(f"Transaksi #{row[0]} - {row[1]} beli {row[4]} x{row[5]} = Rp{int(row[6])}")
        print(f"  Bayar via {row[7]} ({row[8]}), Status Kirim: {row[9]}")
    cursor.close()
    db.close()

def hitung_total_transaksi(id_trans):
    db = connect_mysql()
    cursor = db.cursor()
    cursor.execute("SELECT hitung_total_transaksi(%s)", (id_trans,))
    total = cursor.fetchone()[0]
    print(f"Total transaksi #{id_trans}: Rp{int(total)}")
    cursor.close()
    db.close()
